<?php

abstract class Monolite_Utils {



}
