<?php
global $wp_registered_sidebars;
$layout = isset($this->data['page_sidebar_position']) ? $this->data['page_sidebar_position'] : 'no';
$sidebars_list = array();
foreach ($wp_registered_sidebars as $sidebar => $attrs) {
    $sidebars_list[$attrs['id']] = $attrs['name'];
}

$port_cats_array = array('none' => __('Default (All Categories)', 'monolite-core'));
$port_cats = get_terms( MONOLITE_SLUG . '_portfolio_category', 'orderby=name&order=ASC&hide_empty=1' );
foreach ($port_cats as $key => $value) {
    $port_cats_array[$value->term_id] = $value->name;
}

// PAGE
$meta_boxes[] = array(
    'id' => MONOLITE_SLUG . '_page_settings',
    'title' => __('Page Settings', 'monolite-core'),
    'pages' => array( 'page' ),
    'context' => 'normal',
    'priority' => 'high',
    'autosave' => true,

    'fields' => array(
        // Subtitle
        array(
            'name'  => 'Subtitle:',
            'id'    => MONOLITE_SLUG . "_subtitle",
            'type'  => 'hidden'
        ),

        // Category for portfolio page
        array(
            'name'    =>  __('Portfolio Category:', 'monolite-core'),
            'id'      =>  MONOLITE_SLUG . "_page_portfolio_cat",
            'type'    =>  'select',
            'desc'    =>  __('Select category for this page. This category <b>should be</b> a parent category.', 'monolite-core'),
            'options' =>  $port_cats_array,
            'std'     =>  'none',
        ),

        // Breadcrumbs
        array(
            'name'    => __('Breadcrumbs:', 'monolite-core'),
            'id'   => MONOLITE_SLUG . "_page_breadcrumbs",
            'type'    => 'select',
            'desc'  => __('By default page used general theme settings, defined on '.MONOLITE_NAME.' Options page.', 'monolite-core'),
            'options' => array(
                '-1' => __('Default', 'monolite-core'),
                '1' => __('Show', 'monolite-core'),
                '0' => __('Hide', 'monolite-core'),
            ),
            'std'  => '-1',
        )

    )
);

$meta_boxes[] = array(
    'id' => MONOLITE_SLUG . '_page_layout',
    'title' => __('Page Layout', 'monolite-core'),
    'pages' => array( 'page' ),
    'context' => 'side',
    'priority' => 'low',
    'autosave' => true,

    'fields' => array(
        // Layout
        array(
            'id'       => MONOLITE_SLUG . '_page_layout',
            'type'     => 'image_select',
            'options'  => array(
                'right' => MONOLITE_URI . 'core/options/redux-framework/ReduxCore/assets/img/2cr.png',
                'no'  => MONOLITE_URI . 'core/options/redux-framework/ReduxCore/assets/img/1col.png',
                'left'  => MONOLITE_URI . 'core/options/redux-framework/ReduxCore/assets/img/2cl.png',
            ),
            'std' => $layout
        ),
        // Sidebars
            array(
                'name'  => null,
                'id'    => MONOLITE_SLUG . "_page_widgets_area",
                'desc'  => __('Select widgets area for this page.', 'monolite-core'),
                'type'  => 'select_advanced',
                'multiple'    => false,
                'options'  => $sidebars_list,
                'placeholder' => __('Select Widgets Area', 'monolite-core')
            )
    )
);
