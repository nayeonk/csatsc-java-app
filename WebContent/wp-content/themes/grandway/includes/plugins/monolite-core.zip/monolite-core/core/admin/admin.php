<?php

new Monolite_by_Cu7ious_admin();

class Monolite_by_Cu7ious_admin {

  public function __construct ()
  {
    $this->includeEnqueues();
    add_action('admin_menu', array($this, 'simplify_admin_UI'), 999);
    add_action('admin_print_scripts', array($this, 'get_screen_object'));
  }

  public function includeEnqueues ()
  {
    require_once MONOLITE_ADMIN . '/enqueues/admin_scripts.php';
    require_once MONOLITE_ADMIN . '/enqueues/admin_styles.php';
  }

  public function simplify_admin_UI ()
  {
    if (class_exists('RevSliderAdmin'))
      remove_menu_page('themepunch-google-fonts');

    if (class_exists('Envato_WP_Toolkit'))
      remove_menu_page(EWPT_PLUGIN_SLUG);

    if (class_exists('Ultimate_VC_Addons'))
      remove_menu_page('bsf-dashboard');
  }

  public function get_screen_object ()
  {
      $screen = get_current_screen();

      if ($screen->id == 'nav-menus') {
        // Set Menu Description Screen Option
        add_filter('manage_nav-menus_columns', array($this, '_enable_nav_menu_description_by_default'));
      }
  }

  public function _enable_nav_menu_description_by_default ($columns)
  {
    $desc_key = 'managenav-menuscolumnshidden';
    $hidden   = get_user_option( $desc_key );
    $user_id  = wp_get_current_user()->ID;

    if (!$hidden) {
      update_user_option(
          $user_id,
          $desc_key,
          array ( 0 => 'link-target', 1 => 'css-classes', 2 => 'xfn' )
      );
    } elseif (false !== ($key = array_search('description', $hidden))) {
      unset($hidden[$key]);
      update_user_option($user_id, $desc_key, $hidden);
    }

    return $columns;
  }

}
