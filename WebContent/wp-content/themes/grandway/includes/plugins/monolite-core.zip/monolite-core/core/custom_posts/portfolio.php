<?php

new Monolite_by_Cu7ious_Portfolio();

class Monolite_by_Cu7ious_Portfolio {

    public function __construct ()
    {
        // Add our Portfolio Type
        add_action('init', array($this, 'create_portfolio'));
        add_action('init', array($this, 'create_taxonomy'));
        add_action('admin_head', array($this, 'remove_revolution_slider_metabox'));
    }

    function create_portfolio ()
    {
        // Register Custom Post Type
        register_post_type(MONOLITE_SLUG . '_portfolio',
            array(
                'labels' => array(
                    'name' => __('Portfolio', 'monolite-core'),
                    'singular_name' => __('Portfolio Item', 'monolite-core'),
                    'menu_name' => __('Portfolio', 'monolite-core'),
                    'add_new' => __('Add New', 'monolite-core'),
                    'add_new_item' => __('Add New Portfolio Item', 'monolite-core'),
                    'edit' => __('Edit', 'monolite-core'),
                    'edit_item' => __('Edit Portfolio Item', 'monolite-core'),
                    'new_item' => __('New Portfolio Item', 'monolite-core'),
                    'view' => __('View Portfolio', 'monolite-core'),
                    'view_item' => __('View Portfolio Item', 'monolite-core'),
                    'search_items' => __('Search Portfolio Items', 'monolite-core'),
                    'not_found' => __('No Portfolio Items found', 'monolite-core'),
                    'not_found_in_trash' => __('No Portfolio Items found in Trash', 'monolite-core')
                ),
                // Visual Composer
                // 'public' => true,
                // Visual Composer
                'publicly_queryable' => true,
                'show_ui' => true,
                'show_in_nav_menus' => false,
                // 'show_in_nav_menus' => true,
                'show_in_menu' => true,
                'menu_position' => 5,
                'menu_icon' => 'dashicons-portfolio',
                'capability_type' => 'post',
                // Allows your posts to behave like Hierarchy Pages
                'hierarchical' => false,
                'rewrite' => array(
                    'slug'          => 'port-folio',
                    'with_front'    => true
                ),
                'has_archive' => false,
                'supports' => array(
                    'title',
                    'thumbnail'
                ),
                // Allows export in Tools > Export
                'can_export' => true,
                // Add Category and Post Tags support
                'taxonomies' => array(
                    MONOLITE_SLUG . '_portfolio_category'
                )
            )
        );
    }

    public function create_taxonomy ()
    {
        // Register Taxonomy for Portfolio
        register_taxonomy( MONOLITE_SLUG . '_portfolio_category', MONOLITE_SLUG . '_portfolio',
            array(
                'labels' => array(
                    'name'              => _x('Categories', 'taxonomy general name', 'monolite-core'),
                    'singular_name'     => _x('Category', 'taxonomy singular name', 'monolite-core'),
                    'search_items'      => __('Search Categories', 'monolite-core'),
                    'all_items'         => __('All Categories', 'monolite-core'),
                    'parent_item'       => __('Parent Category', 'monolite-core'),
                    'parent_item_colon' => __('Parent Category:', 'monolite-core'),
                    'edit_item'         => __('Edit Category', 'monolite-core'),
                    'update_item'       => __('Update Category', 'monolite-core'),
                    'add_new_item'      => __('Add New Category', 'monolite-core'),
                    'new_item_name'     => __('New Category Name', 'monolite-core'),
                    'menu_name'         => __('Categories', 'monolite-core'),
                ),
                'hierarchical'      => true,
                'show_ui'           => true,
                'show_admin_column' => true,
                'query_var'         => false,
                'rewrite'           => array('slug' => 'category'),
                'sort'              => true
            )
        );
    }

    public function remove_revolution_slider_metabox ()
    {
        remove_meta_box('mymetabox_revslider_0', MONOLITE_SLUG . '_portfolio', 'normal');
    }

}
