<?php

new Monolite_by_Cu7ious_Services();

class Monolite_by_Cu7ious_Services {

    public function __construct ()
    {
        // Add our Services Type
        add_action('init', array($this, 'create_services'));
        add_action('admin_head', array($this, 'remove_revolution_slider_metabox'));
    }

    function create_services ()
    {
        // Register Custom Post Type
        register_post_type(MONOLITE_SLUG . '_services',
            array(
                'labels' => array(
                    'name' => __('Services', 'monolite-core'),
                    'singular_name' => __('Service', 'monolite-core'),
                    'menu_name' => __('Services', 'monolite-core'),
                    'add_new' => __('Add New', 'monolite-core'),
                    'add_new_item' => __('Add New Service Item', 'monolite-core'),
                    'edit' => __('Edit', 'monolite-core'),
                    'edit_item' => __('Edit Service Item', 'monolite-core'),
                    'new_item' => __('New Service Item', 'monolite-core'),
                    'view' => __('View', 'monolite-core'),
                    'view_item' => __('View Service Item', 'monolite-core'),
                    'search_items' => __('Search Service Items', 'monolite-core'),
                    'not_found' => __('No Service Items found', 'monolite-core'),
                    'not_found_in_trash' => __('No Service Item found in Trash', 'monolite-core')
                ),
                'publicly_queryable' => true,
                'show_ui' => true,
                'show_in_nav_menus' => false,
                'show_in_menu' => true,
                'menu_position' => 5,
                'menu_icon' => 'dashicons-marker',
                // Allows your posts to behave like Hierarchy Pages
                'hierarchical' => false,
                'has_archive' => false,
                'supports' => array(
                    'title'
                ),
                // Allows export in Tools > Export
                'can_export' => true,
            )
        );
    }

    public function remove_revolution_slider_metabox ()
    {
        remove_meta_box('mymetabox_revslider_0', MONOLITE_SLUG . '_services', 'normal');
    }

}
