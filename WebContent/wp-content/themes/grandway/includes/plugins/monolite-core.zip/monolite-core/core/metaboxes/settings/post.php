<?php

// POST Formats {
    //MONOLITE_TEAM .  _link_post_custom_fields
    //MONOLITE_TEAM .  _quote_post_custom_fields
    //MONOLITE_TEAM .  _gallery_post_custom_fields
    //MONOLITE_TEAM .  _video_post_custom_fields
    //MONOLITE_TEAM .  _audio_post_custom_fields

    // Link
   $meta_boxes[] = array(
       'id' => MONOLITE_TEAM . '_link_post_custom_fields',
       'title' => __('Link Post Options', 'monolite-core'),
       'pages' => array( 'post' ),
       'context' => 'normal',
       'priority' => 'high',
       'autosave' => true,

       'fields' => array(

            // Link URL
            array(
                'name'  => __('Link URL:', 'monolite-core'),
                'id'    => MONOLITE_SLUG . "_postformat_link_url",
                'desc'  => __('Post title will be a link to the URL.', 'monolite-core'),
                'type'  => 'url',
                'std'   => 'http://google.com',
            ),
// DIVIDER
array(
    'type' => 'divider',
    'id'   => MONOLITE_SLUG . "_postformat_link_id", // Not used, but needed
),
           // Link Target
           array(
               'name'    => __('Target of link:', 'monolite-core'),
               'id'    => MONOLITE_SLUG . "_postformat_link_target",
               'type'    => 'radio',
               'desc'  => __('Set target of link.', 'monolite-core'),
               'options' => array(
                   '_blank' => '_blank: ' . __('New window or tab', 'monolite-core') . "<br />",
                   '_self' =>  '_self: '. __('Same window or tab', 'monolite-core')
               ),
               'std'  => '_blank',
           ),
// DIVIDER
array(
    'type' => 'divider',
    'id'   => MONOLITE_SLUG . "_postformat_link_id2", // Not used, but needed
),
           // Link Relationship
           array(
               'name'  => __('Link Relationship (optional):', 'monolite-core'),
               'id'    => MONOLITE_SLUG . "_postformat_link_rel",
               'desc'  => __('Set link "rel" attribute. Example: nofollow, dofollow or etc.', 'monolite-core'),
               'type'  => 'text'
               // 'std'   =>
           ),

       )
   );

    // Quote
   $meta_boxes[] = array(
       'id' => MONOLITE_TEAM . '_quote_post_custom_fields',
       'title' => __('Quote Post Options', 'monolite-core'),
       'pages' => array( 'post' ),
       'context' => 'normal',
       'priority' => 'high',
       'autosave' => true,

       'fields' => array(

            // Quote text
            array(
                'name' => __('Quote text:', 'monolite-core'),
                'desc' => __('Add text for quote.', 'monolite-core'),
                'id'   => MONOLITE_SLUG . "_postformat_quote_text",
                'type' => 'textarea',
                'cols' => 20,
                'rows' => 6,
            ),
// DIVIDER
array(
    'type' => 'divider',
    'id'   => MONOLITE_SLUG . "_postformat_quote_id", // Not used, but needed
),
            //  Quote author
            array(
                'name'  => __('Quote author:', 'monolite-core'),
                'id'    => MONOLITE_SLUG . "_postformat_quote_author",
                'desc'  => __('Who said this quote?', 'monolite-core'),
                'type'  => 'text'
                // 'std'   =>
            ),
       )
   );

    // Gallery
    $meta_boxes[] = array(
        'id' => MONOLITE_TEAM . '_gallery_post_custom_fields',
        'title' => __('Gallery Post Options', 'monolite-core'),
        'pages' => array( 'post' ),
        'context' => 'normal',
        'priority' => 'high',
        'autosave' => true,

        'fields' => array(
            array(
                'name'             => __('Gallery', 'monolite-core'),
                'id'               => MONOLITE_SLUG . "_postformat_gallery",
                'type'             => 'image_advanced',
                'max_file_uploads' => 0,
                'desc'  => __('Ctrl/Cmd + click: select multiply images from media library.', 'monolite-core'),
            )
        )
    );

    // Video
   $meta_boxes[] = array(
       'id' => MONOLITE_TEAM . '_video_post_custom_fields',
       'title' => __('Video Post Options', 'monolite-core'),
       'pages' => array( 'post' ),
       'context' => 'normal',
       'priority' => 'high',
       'autosave' => true,

       'fields' => array(
            // Source switch
            array(
                'name'  => __('Video source:', 'monolite-core'),
                'id'    => MONOLITE_SLUG . "_postformat_video_type",
                'desc'  => __('Select video source.', 'monolite-core'),
                'type'  => 'select',
                'options' => array(
                    'url' => 'URL',
                    'embed' => 'Embed code'
                ),
                'std'   => 'url'
            ),

// DIVIDER
array(
    'type' => 'divider',
    'id'   => MONOLITE_SLUG . "_postformat_video_id", // Not used, but needed
),
            // Video Url
            array(
                'name'  => __('Video Url:', 'monolite-core'),
                'id'    => MONOLITE_SLUG . "_postformat_video_url",
                'desc'  => __('Video URL. For example:<br/>YouTube - <a href="#">https://www.youtube.com/watch?v=BsekcY04xvQ</a><br/>Vimeo - <a href="#">http://vimeo.com/102671169</a>', 'monolite-core'),
                'type'  => 'oembed'
            ),
            // Video Embed
            array(
                'name' => __('Video embed code:', 'monolite-core'),
                'desc' => __('Add your embed code here. <a href="#">Get the example.</a>', 'monolite-core'),
                'id'   => MONOLITE_SLUG . "_postformat_video_embed",
                'type' => 'textarea',
                'cols' => 20,
                'rows' => 6
            )
       )
   );
    // Quote
   $meta_boxes[] = array(
       'id' => MONOLITE_TEAM . '_audio_post_custom_fields',
       'title' => __('Audio Post Options', 'monolite-core'),
       'pages' => array( 'post' ),
       'context' => 'normal',
       'priority' => 'high',
       'autosave' => true,
       'fields' => array(
            // Source switch
            array(
                'name'  => __('Audio source:', 'monolite-core'),
                'id'    => MONOLITE_SLUG . "_postformat_audio_type",
                'desc'  => __('Select audio source.', 'monolite-core'),
                'type'  => 'select',
                'options' => array(
                    'url' => 'URL',
                    'file' => 'File'
                ),
                'std'   => 'url'
            ),
// DIVIDER
array(
    'type' => 'divider',
    'id'   => MONOLITE_SLUG . "_postformat_audio_id", // Not used, but needed
),
            // Audio Url
            array(
                'name'  => __('Audio Url:', 'monolite-core'),
                'id'    => MONOLITE_SLUG . "_postformat_audio_url",
                'desc'  => __('Audio URL. For example:<br/>SoundCloud - <a href="#">https://soundcloud.com/alunageorge/coldplay-magic-alunageorge-remix</a>', 'monolite-core'),
                'type'  => 'oembed'
            ),
            // Audio file
            array(
                'name' => __('Audio file:', 'monolite-core'),
                'desc' => __('Upload your audio file here.', 'monolite-core'),
                'id'   => MONOLITE_SLUG . "_postformat_audio_file",
                'type' => 'file_advanced',
                'max_file_uploads' => 1,
                'mime_type' => 'audio',
            ),
       )
   );
// }

// POST General
$meta_boxes[] = array(
    'id' => MONOLITE_SLUG . '_post_settings',
    'title' => __('Post Settings', 'monolite-core'),
    'pages' => array( 'post' ),
    'context' => 'normal',
    'priority' => 'high',
    'autosave' => true,
    'fields' => array(
        // Subtitle
        array(
            'name'  => 'Subtitle:',
            'id'    => MONOLITE_SLUG . "_subtitle",
            'type'  => 'hidden'
        ),
        // Breadcrumbs
        array(
            'name'    => __('Breadcrumbs:', 'monolite-core'),
            'id'   => MONOLITE_SLUG . "_post_breadcrumbs",
            'type'    => 'select',
            'desc'  => __('By default page used general theme settings, defined on '.MONOLITE_NAME.' Options page.', 'monolite-core'),
            'options' => array(
                '-1' => __('Default', 'monolite-core'),
                '1' => __('Show', 'monolite-core'),
                '0' => __('Hide', 'monolite-core'),
            ),
            'std'  => '-1',
        ),
    )
);
