<?php
/**
* Configuring meta boxes
*
* All the definitions of meta boxes are listed below with comments.
* Please read them CAREFULLY.
*
* For more information, please visit:
* @link http://www.deluxeblogtips.com/meta-box/
*/

new Monolite_by_Cu7ious_Metaboxes();

class Monolite_by_Cu7ious_Metaboxes {

  private $data;

  public function __construct ()
  {
    $this->set_theme_options();
    add_filter('rwmb_meta_boxes', array($this, 'register_meta_boxes'));
  }

  /**
   * Register meta boxes
   *
   * @return void
   */
  public function register_meta_boxes( $meta_boxes )
  {
    require MONOLITE_DIR . 'core/metaboxes/settings/page.php';
    require MONOLITE_DIR . 'core/metaboxes/settings/post.php';
    require MONOLITE_DIR . 'core/metaboxes/settings/portfolio.php';
    require MONOLITE_DIR . 'core/metaboxes/settings/team.php';
    require MONOLITE_DIR . 'core/metaboxes/settings/services.php';

    // Check if WooCommerce is active
    if (in_array('woocommerce/woocommerce.php', apply_filters('active_plugins', get_option('active_plugins'))))
      require MONOLITE_DIR . 'core/metaboxes/settings/woo-products.php';

    return $meta_boxes;
  }

  // makes theme options visible for metaboxes configs
  public function set_theme_options ()
  {
    global $PhoenixData;
    $this->data = $PhoenixData;
  }

}
