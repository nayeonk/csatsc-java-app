<?php

$port_cats_array = array('none' => __('Default (All Categories)', 'monolite-core'));
$port_cats = get_terms( MONOLITE_SLUG . '_portfolio_category', 'orderby=name&order=ASC&hide_empty=1' );
foreach ($port_cats as $key => $value) {
    $port_cats_array[$value->term_id] = $value->name;
}

// Portfolio box
$meta_boxes[] = array(
    'id' => MONOLITE_SLUG . '_portfolio_gallery',
    'title' => __('Portfolio Gallery', 'monolite-core'),
    'pages' => array( MONOLITE_SLUG . '_portfolio' ),
    'context' => 'normal',
    'priority' => 'high',
    'autosave' => true,

    'fields' => array(

        // Subtitle
        array(
            'name'  => 'Subtitle:',
            'id'    => MONOLITE_SLUG . "_subtitle",
            'type'  => 'hidden'
        ),
        // Image Gallery
        array(
            'id'               => MONOLITE_SLUG . "_portfolio_gallery",
            'type'             => 'image_advanced',
            'max_file_uploads' => 0,
            'desc'  => __('Ctrl/Cmd + click: select multiply images from media library.', 'monolite-core'),
        ),

    )

);


// Portfolio Details
$meta_boxes[] = array(
    'id' => MONOLITE_SLUG . '_portfolio_details',
    'title' => __('Portfolio Details', 'monolite-core'),
    'pages' => array( MONOLITE_SLUG . '_portfolio' ),
    'context' => 'normal',
    'priority' => 'high',
    'autosave' => true,

    'fields' => array(

        // Date (mm.dd.yyyy)
        array(
            'name' => __('Date (mm.dd.yyyy):', 'monolite-core'),
            'id'   => MONOLITE_SLUG . "_portfolio_date",
            'type' => 'date',
            // jQuery date picker options. See here http://api.jqueryui.com/datepicker
            'js_options' => array(
                // 'appendText'      =>
                'dateFormat'      => __('mm.dd.yy', 'monolite-core'),
                'changeMonth'     => true,
                'changeYear'      => true,
                // 'showButtonPanel' => true,
            ),
        ),

// DIVIDER
array(
    'type' => 'divider',
    'id'   => MONOLITE_SLUG . "_portfolio_divider_id1", // Not used, but needed
),

        // Author
        array(
            'name'  => __('Author:', 'monolite-core'),
            'id'    => MONOLITE_SLUG . "_portfolio_author",
            'type'  => 'text',
            'std'   => __('John Doe', 'monolite-core'),
        ),

        // Author URL
        array(
            'name'  => __('Author URL:', 'monolite-core'),
            'id'    => MONOLITE_SLUG . "_portfolio_author_url",
            'type'  => 'url',
            'std'   => 'http://example.net',
        ),

// DIVIDER
array(
    'type' => 'divider',
    'id'   => MONOLITE_SLUG . "_portfolio_divider_id2", // Not used, but needed
),

        // Client
        array(
            'name'  => __('Client:', 'monolite-core'),
            'id'    => MONOLITE_SLUG . "_portfolio_client",
            'type'  => 'text',
            'std'   => __('Jane Doe', 'monolite-core'),
        ),

        // Client URL
        array(
            'name'  => __('Client URL:', 'monolite-core'),
            'id'    => MONOLITE_SLUG . "_portfolio_client_url",
            'type'  => 'url',
            'std'   => 'http://example.net',
        ),

// DIVIDER
array(
    'type' => 'divider',
    'id'   => MONOLITE_SLUG . "_portfolio_divider_id3", // Not used, but needed
),

        // Excerpt
        array(
            'name' => __('Excerpt:', 'monolite-core'),
            'id'   => MONOLITE_SLUG . "_portfolio_excerpt",
            'type' => 'textarea',
            'raw'  => false,
            'std'  => __('Your excerpt here...', 'monolite-core'),
            'cols' => 20,
            'rows' => 3,
        ),

// DIVIDER
array(
    'type' => 'divider',
    'id'   => MONOLITE_SLUG . "_portfolio_divider_id4", // Not used, but needed
),

        // Description
        array(
            'name' => __('Description:', 'monolite-core'),
            'id'   => MONOLITE_SLUG . "_portfolio_description",
            'type' => 'wysiwyg',
            'raw'  => false,
            'std'  => __('Your Description here...', 'monolite-core'),
            'options' => array(
                'textarea_rows' => 6,
                'teeny'         => true,
                'media_buttons' => false,
            ),
        ),
    )
);

// Portfolio Settings
$meta_boxes[] = array(
    'id' => MONOLITE_SLUG . '_post_settings',
    'title' => __('Portfolio Settings', 'monolite-core'),
    'pages' => array( MONOLITE_SLUG . '_portfolio' ),
    'context' => 'normal',
    'priority' => 'low',
    'autosave' => false,

    'fields' => array(
        // Breadcrumbs
        array(
            'name'    => __('Breadcrumbs:', 'monolite-core'),
            'id'   => MONOLITE_SLUG . "_port_breadcrumbs",
            'type'    => 'select',
            'desc'  => __('By default page used general theme settings, defined on '.MONOLITE_NAME.' Options page.', 'monolite-core'),
            'options' => array(
                '-1' => __('Default', 'monolite-core'),
                '1' => __('Show', 'monolite-core'),
                '0' => __('Hide', 'monolite-core'),
            ),
            'std'  => '-1',
        ),

// DIVIDER
array(
    'type' => 'divider',
    'id'   => MONOLITE_SLUG . "_portfolio_divider_id4", // Not used, but needed
),

        // Category for portfolio page
        array(
            'name'    =>  __('Portfolio Category:', 'monolite-core'),
            'id'      =>  MONOLITE_SLUG . "_portfolio_recent_works_cat",
            'type'    =>  'select',
            'desc'    =>  __('Select category for "Recent Works" section.', 'monolite-core'),
            'options' =>  $port_cats_array,
            'std'     =>  'none',
        ),

    )
);
