<?php

// If this file is called directly, abort.
if (!defined('WPINC'))
  die;

new Monolite_by_Cu7ious();

class Monolite_by_Cu7ious {

  private $theme;

  public function __construct ($debug = false)
  {
    $this->defineConstants();
    $this->theme = $this->_checkTheTheme();
    $this->addOptionsFramework();
    $this->loadHelpers($debug);
    $this->includeMetaboxes();
    $this->loadAdminFiles();
    $this->registerCustomPosts();
    // $this->addShortcodes();

    add_action('plugins_loaded', array($this, 'setTextDomain'));
  }

  /*
   Defines the constant paths for use within the theme.
  */
  private function defineConstants ()
  {
    define('MONOLITE_DIR', plugin_dir_path(__FILE__) . '../');
    define('MONOLITE_URI', plugin_dir_url( __FILE__ ). '../');

    define('MONOLITE_ADMIN', MONOLITE_DIR . 'core/admin');
    define('MONOLITE_ADMIN_URI', MONOLITE_URI . 'core/admin');

    define('MONOLITE_THEME', get_template_directory());
    define('MONOLITE_THEME_URI', get_template_directory_uri());

    define('MONOLITE_TEAM', 'PhoenixTeam');
    define('MONOLITE_NAME', 'GrandWay');
    define('MONOLITE_SLUG', 'grandway');

    // Redefine meta box path and URL
    define('RWMB_DIR', trailingslashit(MONOLITE_DIR . 'core/metaboxes/meta-box'));
    define('RWMB_URL', trailingslashit(MONOLITE_URI . 'core/metaboxes/meta-box'));
  }


  public function setTextDomain ()
  {
    load_plugin_textdomain('monolite-core', false, MONOLITE_DIR . 'core/languages/');
  }


  private function addOptionsFramework ()
  {
    if ($this->theme) {
      if (!class_exists('ReduxFramework')) {
        require_once MONOLITE_DIR . 'core/options/redux-framework/ReduxCore/framework.php';
        require_once MONOLITE_THEME . '/includes/options/config.php';

        return true;
      }
    }

    return false;
  }


  private function registerCustomPosts ()
  {
    require_once MONOLITE_DIR . 'core/custom_posts/portfolio.php';
    require_once MONOLITE_DIR . 'core/custom_posts/team.php';
    require_once MONOLITE_DIR . 'core/custom_posts/services.php';
  }


  /*
   Loads the core theme functions.
  */
  private function loadHelpers ($debug = false)
  {
    require_once MONOLITE_DIR . 'core/helpers/utils.php';

    if ($debug) add_action('wp_footer', array($this, '_debug_showTemplateName'));
  }


  public function _debug_showTemplateName ()
  {
    global $template;

    if (current_user_can('administrator')) {
      echo "<div style='text-align:center;font-size:smaller'>";
      print_r("To serve this page <strong>" . esc_html(basename($template)) . "</strong> is used.");
      echo "</div>";
    }
  }


  /*
   Load admin files.
  */
  private function loadAdminFiles ()
  {
    if (is_admin())
      require_once MONOLITE_ADMIN . '/admin.php';
  }


  private function includeMetaboxes ()
  {
    // Include the meta box script
    require_once RWMB_DIR . 'meta-box.php';
    // Include the meta box definition (the file where you define meta boxes)
    require_once MONOLITE_DIR . 'core/metaboxes/config.php';
  }


  private function _checkTheTheme ()
  {
    $theme = wp_get_theme();

    if ($theme->get('Name') == MONOLITE_NAME ||
      $theme->parent() && $theme->parent()->get('Name') == MONOLITE_NAME) {
        return true;
      }

    return false;
  }

}

// register_activation_hook(__FILE__, 'activateMonolite_Core');
// register_deactivation_hook(__FILE__, 'deactivateMonolite_Core');

// function activateMonolite_Core () {
// }


// function deactivateMonolite_Core () {
// }
