<?php
/**
 * Monolite Core
 *
 * Ultimate origin of the premium features
 *
 * @link              http://cu7io.us/monolite-core
 * @since             1.0.0
 * @package           Monolite Core
 *
 * @wordpress-plugin
 * Plugin Name:       Monolite Core
 * Plugin URI:        http://cu7io.us/monolite-core/
 * Description:       Ultimate origin of the premium features. Custom post types, metaboxes, shortcodes and many many more.
 * Version:           1.0.0
 * Author:            Cu7ious
 * Author URI:        http://cu7io.us/
 * License:           GPL-3.0+
 * License URI:       http://www.gnu.org/licenses/gpl-3.0.txt
 * Text Domain:       monolite-core
 * Domain Path:       /core/langs
 */

// If this file is called directly, abort.
if (!defined('WPINC')) {
  die;
}

require_once plugin_dir_path(__FILE__) . 'core/core.php';
