<?php
    // WooCommerce PRODUCTS
    $meta_boxes[] = array(
        'id' => MONOLITE_SLUG . '_woo_products_settings',
        'title' => __(MONOLITE_NAME . 'Product Settings', 'monolite-core'),
        'pages' => array( 'product' ),
        'context' => 'normal',
        'priority' => 'high',
        'autosave' => true,

        'fields' => array(
            // Subtitle
            array(
                'name'  => 'Subtitle:',
                'id'    => MONOLITE_SLUG . "_subtitle",
                'type'  => 'hidden'
            )
        )
    );
