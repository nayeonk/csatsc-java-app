<?php

new Monolite_by_Cu7ious_Admin_Styles();

class Monolite_by_Cu7ious_Admin_Styles {

    public function __construct ()
    {
        add_action('admin_enqueue_styles', array($this, 'enqueue_styles')); // Add CSS to wp_head
        add_action('admin_print_styles', array($this, 'conditional_styles')); // Add Conditional Page CSS
    }

    // Enqueue styles
    public function enqueue_styles ()
    {

    }

    // Load conditional styles
    public function conditional_styles ()
    {
        $screen = get_current_screen();
        switch ($screen->id) {
            case 'toplevel_page_' . MONOLITE_SLUG . '_options':
                wp_enqueue_style(MONOLITE_SLUG . '-options', MONOLITE_ADMIN_URI . '/assets/css/options.css', array(), '1.0', 'all');
                break;
            case 'post':
                wp_enqueue_style(MONOLITE_SLUG . '-post', MONOLITE_ADMIN_URI . '/assets/css/post.css', array(), '1.0', 'all');
                break;
            case 'page':
                wp_enqueue_style(MONOLITE_SLUG . '-page', MONOLITE_ADMIN_URI . '/assets/css/page.css', array(), '1.0', 'all');
                break;
            case  MONOLITE_SLUG . '_portfolio':
                wp_enqueue_style(MONOLITE_SLUG . '-portfolio', MONOLITE_ADMIN_URI . '/assets/css/portfolio.css', array(), '1.0', 'all');
                break;

            case MONOLITE_SLUG . '_team': break;

            case MONOLITE_SLUG . '_services':
                wp_enqueue_style(MONOLITE_SLUG . '-fontawesome', MONOLITE_ADMIN_URI . '/assets/css/font-awesome.min.css', array(), '4.1.0', 'all');
                wp_enqueue_style(MONOLITE_SLUG . '-et-line', MONOLITE_ADMIN_URI . '/assets/css/et-line.css', array(), '1.0.0', 'all');
                wp_enqueue_style(MONOLITE_SLUG . '-services', MONOLITE_ADMIN_URI . '/assets/css/services.css', array(), '1.0', 'all');
                break;
        }
    }

}
