<?php

new Monolite_by_Cu7ious_Admin_Scripts();

class Monolite_by_Cu7ious_Admin_Scripts {

    public function __construct ()
    {
        // add_action('admin_enqueue_scripts', array($this, 'enqueue_scripts')); // Add Custom Scripts to wp_head
        add_action('admin_print_scripts', array($this, 'conditional_scripts')); // Add Conditional Page Scripts
    }


    // Load conditional scripts
    public function conditional_scripts ()
    {
        global $reduxConfig;

        $adminData = array(
            'THEME_SLUG' => MONOLITE_SLUG,
            'teamFieldsMatchErr' => __("Number of \"Social Networks\" fields and\n\"Social URLs\" fields must match!", 'monolite-core'),
            'teamFieldaFilledErr' => __("All fields of \"Social Networks\" group\nmust be filled!", 'monolite-core'),
            'serviceIconDescription' => __('Select an icon for your service item. Icons belong to <a href="http://fortawesome.github.io/Font-Awesome/" target="_blank">FontAwesome</a>, the iconic font designed for Bootstrap.', 'monolite-core')
        );
        wp_localize_script('jquery', MONOLITE_TEAM, $adminData);

        $screen = get_current_screen();
        switch ($screen->id) {
            case 'post':
                wp_enqueue_script(MONOLITE_SLUG . '-post-formats', MONOLITE_ADMIN_URI . '/assets/js/post-formats.js', array('jquery'), '1.0.0', true);
                break;
            case 'page':
                wp_enqueue_script(MONOLITE_SLUG . '-page', MONOLITE_ADMIN_URI . '/assets/js/page.js', array('jquery'), '1.0.0', true);
                break;
            case  MONOLITE_SLUG . '_portfolio':

                break;
            case MONOLITE_SLUG . '_team':
                wp_enqueue_script(MONOLITE_SLUG . '-post-type-team', MONOLITE_ADMIN_URI . '/assets/js/team.js', array('jquery'), '1.0.0', true);
                break;
            case MONOLITE_SLUG . '_services':
                wp_enqueue_script(MONOLITE_SLUG . '-post-type-services', MONOLITE_ADMIN_URI . '/assets/js/services.js', array('jquery'), '1.0.0', true);
                break;
            case MONOLITE_SLUG . '_testims':
                // nothing yet
                break;
            case 'product':
                wp_enqueue_script('woo-products', MONOLITE_ADMIN_URI . '/assets/js/woo-products.js', array('jquery'), '1.0.0', true);
                break;
            case 'toplevel_page_'. MONOLITE_SLUG .'_options':
                if ($reduxConfig->args['dev_mode']) {
                    wp_enqueue_script('options-devmode', MONOLITE_ADMIN_URI . '/assets/js/options-devmode.js', array('jquery'), '1.0.0', true);
                }
                break;
        }
    }

}
