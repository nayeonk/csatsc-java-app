<?php

$multisocials = isset($this->data['multisocials']) ? $this->data['multisocials'] : false;

$meta_boxes[MONOLITE_SLUG . '_team'] = array(
    'id' => MONOLITE_SLUG . '_team',
    'title' => __('Team Member Details', 'monolite-core'),
    'pages' => array( MONOLITE_SLUG . '_team' ),
    'context' => 'normal',
    'priority' => 'high',
    'autosave' => true,

    'fields' => array(
        array(
            'name'             => __('Picture:', 'monolite-core'),
            'id'               => MONOLITE_SLUG . "_team_member_pic",
            'type'             => 'image_advanced',
            'max_file_uploads' => 1,
        ),
// DIVIDER
array(
    'type' => 'divider',
    'id'   => MONOLITE_SLUG . "_team_member_divider", // Not used, but needed
),
        // Abuut
        array(
            'name' => __('About:', 'monolite-core'),
            'desc' => __('Some words about the member.', 'monolite-core'),
            'id'   => MONOLITE_SLUG . "_team_member_text",
            'type' => 'textarea',
            'cols' => 20,
            'rows' => 6,
        ),
// DIVIDER
array(
    'type' => 'divider',
    'id'   => MONOLITE_SLUG . "_team_member_divider1", // Not used, but needed
),
        // Company Position
        array(
            'name'  => __('Position:', 'monolite-core'),
            'id'    => MONOLITE_SLUG . "_team_member_position",
            'desc' => __('Ex:', 'monolite-core') . ' <a href="#" class="'. MONOLITE_SLUG . '-demo-content">' . __('Web Developer', 'monolite-core') .'</a> or <a href="#" class="'. MONOLITE_SLUG . '-demo-content">'. __('Sales Manager', 'monolite-core') .'</a>',
            'type'  => 'text',
        ),
        // Email Address
        array(
            'name'  => __('Email (optional):', 'monolite-core'),
            'id'    => MONOLITE_SLUG . "_team_member_email", // fa-envelope
            'desc'  => __('Email will be published with <b>antispambot</b> protection.', 'monolite-core'),
            'type'  => 'text',
        ),
        // Social Networks
        array(
            'name' => __('Social Networks', 'monolite-core'),
            'type' => 'heading',
            'id'   => 'fake_id', // Not used but needed for plugin
        ),
    )
);

if ($multisocials) {
    $meta_boxes[MONOLITE_SLUG . '_team']['fields'][] =
        array(
            'name'  => __('Social Networks:', 'monolite-core'),
            'id'    => MONOLITE_SLUG . "_team_socials_name",
            'desc'  => __('Select social network. Clone this field to choose another network.', 'monolite-core'),
            'type'  => 'select_advanced',
            'multiple'    => false,
            'options'  => array(
                "Android" => "Android",
                "Apple" => "Apple",
                "Behance" => "Behance",
                "Bitbucket" => "Bitbucket",
                "Bitcoin" => "Bitcoin",
                "Btc" => "Btc",
                "Codepen" => "Codepen",
                "Css3" => "Css3",
                "Delicious" => "Delicious",
                "Deviantart" => "Deviantart",
                "Digg" => "Digg",
                "Dribbble" => "Dribbble",
                "Dropbox" => "Dropbox",
                "Drupal" => "Drupal",
                "Empire" => "Empire",
                "Facebook" => "Facebook",
                "Flickr" => "Flickr",
                "Foursquare" => "Foursquare",
                "Git" => "Git",
                "Github" => "Github",
                "Gittip" => "Gittip",
                "Google" => "Google",
                "Html5" => "Html5",
                "Instagram" => "Instagram",
                "Joomla" => "Joomla",
                "JsFiddle" => "JsFiddle",
                "LinkedIn" => "LinkedIn",
                "Linux" => "Linux",
                "maxCDN" => "maxCDN",
                "openID" => "openID",
                "PageLines" => "PageLines",
                "Pied" => "Pied",
                "Pinterest" => "Pinterest",
                "QQ" => "QQ",
                "Rebel" => "Rebel",
                "Reddit" => "Reddit",
                "Renren" => "Renren",
                "Skype" => "Skype",
                "Slack" => "Slack",
                "Soundcloud" => "Soundcloud",
                "Spotify" => "Spotify",
                "Steam" => "Steam",
                "Stumbleupon" => "Stumbleupon",
                "Trello" => "Trello",
                "Tumblr" => "Tumblr",
                "Twitter" => "Twitter",
                "Vine" => "Vine",
                "Vk" => "Vk",
                "Wechat" => "Wechat",
                "Weibo" => "Weibo",
                "Weixin" => "Weixin",
                "Windows" => "Windows",
                "WordPress" => "WordPress",
                "Xing" => "Xing",
                "Yahoo" => "Yahoo",
                "YouTube" => "YouTube",
                "Google +" => "Google +",
                "Hacker News" => "Hacker News",
                "Stack Exchange" => "Stack Exchange",
                "Stack Overflow" => "Stack Overflow",
            ),
            'placeholder' => __('Select Social Network', 'monolite-core'),
            'clone' => true
    );
    $meta_boxes[MONOLITE_SLUG . '_team']['fields'][] =
        array(
            'type' => 'divider',
            'id'   => MONOLITE_SLUG . "_team_member_divider4", // Not used, but needed
    );
    $meta_boxes[MONOLITE_SLUG . '_team']['fields'][] =
        array(
            'name'  => __('Social URLs:', 'monolite-core'),
            'id'    => MONOLITE_SLUG . "_team_socials_url",
            'desc'  => __('Select URLs for your social networks defined above. Clone this field to choose another network.<br/>Note that the number and order of these fields must comply with social networks fields , defined above.', 'monolite-core'),
            'type'  => 'url',
            'clone' => true
    );
} else {
    $meta_boxes[MONOLITE_SLUG . '_team']['fields'][] =
        array(
            'name'  => __('Facebook URL:', 'monolite-core'),
            'id'    => MONOLITE_SLUG . "_team_fb_url",
            'desc'  => __('Ex:', 'monolite-core') . ' <a href="#" class="'. MONOLITE_SLUG . '-demo-content">'. 'https://www.facebook.com/matt.mullenweg</a>',
            'type'  => 'url'
    );
    $meta_boxes[MONOLITE_SLUG . '_team']['fields'][] =
        array(
            'type' => 'divider',
            'id'   => MONOLITE_SLUG . "_team_member_divider4", // Not used, but needed
    );
    $meta_boxes[MONOLITE_SLUG . '_team']['fields'][] =
        array(
            'name'  => __('Twitter URL:', 'monolite-core'),
            'id'    => MONOLITE_SLUG . "_team_twt_url",
            'desc'  => __('Ex:', 'monolite-core') . ' <a href="#" class="'. MONOLITE_SLUG . '-demo-content">'. 'https://twitter.com/Ph0enixTeam</a>',
            'type'  => 'url'
    );
    $meta_boxes[MONOLITE_SLUG . '_team']['fields'][] =
        array(
            'type' => 'divider',
            'id'   => MONOLITE_SLUG . "_team_member_divider5", // Not used, but needed
    );
    $meta_boxes[MONOLITE_SLUG . '_team']['fields'][] =
        array(
            'name'  => __('LinkedIn URL:', 'monolite-core'),
            'id'    => MONOLITE_SLUG . "_team_linkedin_url",
            'desc'  => __('Ex:', 'monolite-core') . ' <a href="#" class="'. MONOLITE_SLUG . '-demo-content">'. 'https://www.linkedin.com/pub/guido-van-rossum/0/756/4a0</a>',
            'type'  => 'url',
    );
    $meta_boxes[MONOLITE_SLUG . '_team']['fields'][] =
        array(
            'type' => 'divider',
            'id'   => MONOLITE_SLUG . "_team_member_divider6", // Not used, but needed
    );
    $meta_boxes[MONOLITE_SLUG . '_team']['fields'][] =
        array(
            'name'  => __('Google+ URL:', 'monolite-core'),
            'id'    => MONOLITE_SLUG . "_team_gplus_url",
            'desc'  => __('Ex:', 'monolite-core') . ' <a href="#" class="'. MONOLITE_SLUG . '-demo-content">'. 'https://plus.google.com/+LinusTorvalds/posts</a>',
            'type'  => 'url'
    );
}
