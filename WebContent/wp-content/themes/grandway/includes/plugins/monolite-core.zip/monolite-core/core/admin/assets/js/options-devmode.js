(function () {
    "use strict";

    jQuery(function($){

        setTimeout(function() {

            redux.rAds = null;

        }, 1000);

    });
})();
