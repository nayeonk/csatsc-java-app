jQuery(function($) {
    "use strict";

    $('#grandway_woo_products_settings').hide();
});
